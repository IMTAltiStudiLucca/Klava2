/*
 * Created on Mar 15, 2016
 */
package klava.manager;

import klava.Tuple;

public class TupleRequest 
{
    Tuple template;
    
    
    public TupleRequest()
    {
        
    }
}
