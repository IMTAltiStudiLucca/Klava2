package klava;

public class KlavaTupleParsingException extends KlavaException {

    /**
     * 
     */
    private static final long serialVersionUID = 3016080442316696944L;

    public KlavaTupleParsingException() {
        super();
    }

    public KlavaTupleParsingException(String s) {
        super(s);
    }
}