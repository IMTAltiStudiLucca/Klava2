package klava.new_communication;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ThreadFactory;

import interfaces.ITupleSpace;
import klava.TupleSpace;

public class NIOListener {
	
    // main channel for listening
	ServerSocketChannel ssChannel;
	// selector for accepting and reading
	Selector acceptSelector;
	// thread for listening
    private Thread ioThread; 
    // object for stopping ioThread
    boolean stopFLag = false;
    
//	private ThreadFactory threadFactory;

   
    // reference to local tuple space
    TupleSpace tupleSpace;
    TCPNIOEntity tcpnioEntity;
	
	public NIOListener(int port, TupleSpace tupleSpace, TCPNIOEntity tcpnioEntity)
	{
	    this.tupleSpace = tupleSpace;
	    this.tcpnioEntity = tcpnioEntity;
	    
		try {
			ssChannel = ServerSocketChannel.open();
			ssChannel.bind(new InetSocketAddress(port));
			ssChannel.configureBlocking(false);
			
			acceptSelector = Selector.open();	
	        ssChannel.register(acceptSelector, SelectionKey.OP_ACCEPT);

            Runnable run = new Runnable() {
               
                public void run() {
                	try {
						processingLoop();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}                            // This runs for a long time
                    ioThread = null;
                }   // end run
            };  // end runnable
            
			ioThread = new Thread( run, this.getClass().getName() );
			//ioThread.start();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void start()
	{
		stopFLag = false;
		if(ioThread != null)
			ioThread.start();
	}
	
	public void shutdown()
	{
		stopFLag = true;
		//ioThread.interrupt();
	}
	
	
	private void processingLoop() throws IOException
	{
	    int countIncomming = 0;
	    
        while(true) {
            int count = acceptSelector.select();
            if(stopFLag == true)
            	break;
            
            if(count != 0 )
            {
                for (Iterator<SelectionKey> i = acceptSelector.selectedKeys().iterator();i.hasNext();) 
                {                  
                    SelectionKey key = i.next();
                    
                    if (!key.isValid()) {
                        System.out.println("key is not valid");
                        key.cancel();
                        continue;
                    } 
                    
                    if(key.isAcceptable()) 
                    {
                   // 	System.out.println("new request");
                    	//ServerSocketChannel c = (ServerSocketChannel)key.channel();
                		SocketChannel client = ssChannel.accept();
                		client.configureBlocking(false);
                		
                		// register for the read operation
                		client.register(acceptSelector, SelectionKey.OP_READ);
                		
                    } else if(key.isReadable())
                    {
                        // run a new thread for processing
                    	SocketChannel readChannel = (SocketChannel)key.channel();
                    	
                    	// remove subscription for the read operation
                    	SelectionKey keyToRemove = readChannel.keyFor(acceptSelector);
                //    	keyToRemove.cancel();
                    	key.cancel();
                    	
                    	
                    	// do it in a new thread
                        Thread t = new RequestProcessor(readChannel, tupleSpace, tcpnioEntity);
                        t.start();    
                          
                    }
                   /* else
                    {
                        SocketChannel anotherSocketChannel = (SocketChannel)key.channel();
                        anotherSocketChannel.close();
                    }*/
                    i.remove();
                     
                }
            }
        }
		
	}
	
}
