package klava.new_communication;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.HashMap;

import interfaces.ITupleSpace;
import klava.Tuple;
import klava.TupleSpace;
import klava.new_communication.TuplePack.eTupleOperation;


public class RequestProcessor extends Thread {
    // channel for listening and reading
    SocketChannel socChannel;
    // reference to local tuple space;
    TupleSpace tupleSpace;
    
    TCPNIOEntity tcpnioEntity;
    
    public RequestProcessor(SocketChannel socChannel, TupleSpace tupleSpace, TCPNIOEntity tcpnioEntity) {
        this.socChannel = socChannel;
        this.tupleSpace = tupleSpace;
        this.tcpnioEntity = tcpnioEntity;
    }

    public void run() {
        try {

        	 ByteBuffer buffer = ByteBuffer.allocate(100);
        	 buffer.clear();

        	 ByteArrayOutputStream out = new ByteArrayOutputStream(); 
        	 
        	 int count = 0;
             int read;

             while ((read = socChannel.read(buffer)) > 0) 
             {
            	 buffer.flip();
            	 byte[] arr = new byte[buffer.remaining()];
            	 buffer.get(arr);
            	 
            	 out.write(arr);
            	 
            	 buffer.clear();
            	 count += read;
             }        

             byte[] readBytes = out.toByteArray();
             out.close();
             socChannel.close();
                 
             if(count != readBytes.length)
                 System.err.println("RequestProcessor: reading (count != readBytes.length)");
             
             
             if(count > 0)
             {
            	 TuplePack tPacket = (TuplePack)TuplePack.deserializeObject(out.toByteArray());
            	// System.out.println("new tuple arrived");
            	 

            	 processPacket(tPacket, tupleSpace, tcpnioEntity);
             }
            
           //  socChannel.close();
		                	
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    
    public static void processPacket(TuplePack tPacket, TupleSpace tupleSpace, TCPNIOEntity tcpnioEntity) throws InterruptedException
    {
       long start = System.currentTimeMillis();
       if(tPacket.operation == eTupleOperation.OUT) 
       {
           //System.out.println(tPacket.tuple);
           // write to the local tuple space
           tupleSpace.out(tPacket.tuple);
       } 
       else if(tPacket.operation == eTupleOperation.READ || 
               tPacket.operation == eTupleOperation.IN) 
       {
 //          System.out.println("request_read_from:" + tPacket.senderPort + "_" + tPacket.operation +"_operation:" + tPacket.operationID);
           
           if(!tPacket.blocking)
           {
               boolean result = false;
               
               if(tPacket.operation == eTupleOperation.READ)
                   result = tupleSpace.read_nb(tPacket.tuple);
               else
                   result = tupleSpace.in_nb(tPacket.tuple);
               
               // #TODOVB
               // here we can use the same channel or use standard NIOSender
               NIOSender sender = new NIOSender(tPacket.senderPort);
               
               eTupleOperation previousOp = tPacket.operation;
               if(result)
               {
                   tPacket.tuple = tPacket.tuple;
                   tPacket.operation = eTupleOperation.TUPLEBACK;
               } else
               {
                   // just send that the tuple is absent
                   tPacket.operation = eTupleOperation.TUPLEABSENT;
               }
               
               // write response
        //       System.out.println("write_to:" + tPacket.senderPort +"_operation:" + tPacket.operationID);
               
               if (!tPacket.blocking)
               {
      //             System.out.println(tPacket.senderPort + ":RequestProcessor:write_response");
               }
               
               sender.write(tPacket);
               
           } else
           {
               // #TODOVB
               // here is the simple version of waiting
                               
               if(tPacket.operation == eTupleOperation.READ)
                   tupleSpace.read(tPacket.tuple);
               else
                   tupleSpace.in(tPacket.tuple);

               //tPacket.tuple = result;
               tPacket.operation = eTupleOperation.TUPLEBACK;
               
               // write response
    //           System.out.println("write_to:" + tPacket.senderPort +"_operation:" + tPacket.operationID);
               
               NIOSender sender = new NIOSender(tPacket.senderPort);
               sender.write(tPacket);       

           }
       }
       else if(tPacket.operation == eTupleOperation.TUPLEABSENT || tPacket.operation == eTupleOperation.TUPLEBACK)
       {
           
  //         System.out.println("read_by:" + tPacket.senderPort +"_operation:" + tPacket.operationID);
           
           
           // just find a request and insert result packet
          
           if (!tPacket.blocking)
           {
      //         System.out.println(tPacket.senderPort + ":RequestProcessor:receive_response");
           }
           
           //synchronized (tcpnioEntity.syncResponseTupleTable) 
           tcpnioEntity.dataPairLock.lock();
           {    
               if(tcpnioEntity.pair == null)
               {
                   System.out.println("tPacket.operationID " + tPacket.operationID);
                   System.out.println("tPacket.operation " + tPacket.operation);
                   
               }
               if(tcpnioEntity.pair.getKey().equals(tPacket.operationID))
               {
                   tcpnioEntity.pair.setValue(tPacket);
               }   
               else
                   System.err.println("Mistake in RequestProcessor");
              // tcpnioEntity.syncResponseTupleTable.notify();
               tcpnioEntity.responseIsBack.signalAll();
           }
           tcpnioEntity.dataPairLock.unlock();
           
           /*
           synchronized (tcpnioEntity.syncResponseTupleTable) 
           {    
               if(tcpnioEntity.responseTupleTable.containsKey(tPacket.operationID))
               {
                   tcpnioEntity.responseTupleTable.replace(tPacket.operationID, tPacket);
               }  
               tcpnioEntity.syncResponseTupleTable.notifyAll();
           }*/
       }
       
       
       long end = System.currentTimeMillis();
     //  System.out.println("time - " + (end-start));
    }
    
    
    

    
   
    
    
}
