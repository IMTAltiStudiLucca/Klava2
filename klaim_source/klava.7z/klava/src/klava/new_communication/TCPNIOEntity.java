package klava.new_communication;

import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import common.CustomPair;
import interfaces.ITupleSpace;
import klava.TupleSpace;


// Requirements:
// 

public class TCPNIOEntity 
{
	String host;
	public int port;
	
	// listener
	NIOListener nioListener = null;
//	NIOSender sender;
	
	// senders
//	HashMap<String, Integer> senderList = new HashMap<String, Integer>();
	
	// for tuple as response
//	HashMap<Long, TuplePack> responseTupleTable = new HashMap<Long, TuplePack>();

	//Object syncResponseTupleTable = new Object();
    CustomPair<Long, TuplePack> pair = null;
    
    final Lock dataPairLock = new ReentrantLock();
    final Condition responseIsBack = dataPairLock.newCondition();
	
	
	// reference to local tuple space
	TupleSpace tupleSpace;
	
	private Long operationSequenceID = 0L;
	
	Queue<TuplePack> requestQueue = new LinkedList<TuplePack>();
    private Thread processorThread; 
	
	
	public TCPNIOEntity(int port, TupleSpace tupleSpace) throws IOException
	{
	    this.port = port;
	    this.tupleSpace = tupleSpace;
		nioListener = new NIOListener(port, tupleSpace, this);
		nioListener.start();

//		sender = new NIOSender(port);
		//runProcessor();
	}
	
	public void sendData(int port, Object obj)
	{
		NIOSender sender = new NIOSender(port);
		sender.write(obj);
	}
	
	public long getNextOperationSequenceID()
	{
	    Long nexOperationID;
	    synchronized (operationSequenceID) {
	        nexOperationID = operationSequenceID++;
        }
	    return nexOperationID;
	}
    
	/*
	public void runProcessor()
	{
	    Runnable run = new Runnable() {
            
            public void run() 
            {
                while (true)
                {
                    try {
                        synchronized (requestQueue) 
                        {
                            if(requestQueue.size() > 0)
                            {
                                TuplePack tPacket = requestQueue.poll();
                                RequestProcessor.processPacket(tPacket, tupleSpace, responseTupleTable);
                            }
                            else
                                requestQueue.wait();
                        }
                        
                    } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }                            // This runs for a long time
                }
            }   // end run
        };  // end runnable
        
        processorThread = new Thread( run, this.getClass().getName() );
        processorThread.start();
	}*/
	
}
