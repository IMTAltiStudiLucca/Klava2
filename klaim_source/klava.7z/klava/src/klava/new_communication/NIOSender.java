package klava.new_communication;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

public class NIOSender
{
		//int port;
		SocketChannel sChannel;
		//ObjectOutputStream  ooStream;
		
		public NIOSender(int port)
		{

			try {
				sChannel = SocketChannel.open();
		        sChannel.configureBlocking(true);
		        if (sChannel.connect(new InetSocketAddress("localhost", port))) 
		        {
		        	//ooStream = new ObjectOutputStream(sChannel.socket().getOutputStream());
		            
		        }
	        
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
		}
		
		
		public void write(Object obj)
        {
            if(obj != null)
            {
                try {
                    byte[] bytes = TuplePack.serializeObject(obj);
                //  System.out.println("size " + bytes.length);
                    ByteBuffer buffer = ByteBuffer.wrap(bytes);
                    
                    sChannel.write(buffer);

                    shutdown();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    
                    System.err.println("error writeObject");
                    e.printStackTrace();
                }
            }
        }
		
/*		public void write(Object obj)
		{
			if(obj != null)
			{
				try {
					byte[] bytes = TuplePack.serializeObject(obj);
				//	System.out.println("size " + bytes.length);
					ByteBuffer buffer = ByteBuffer.wrap(bytes);
					
			        sChannel.write(buffer);

			        shutdown();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					
					System.err.println("error writeObject");
					e.printStackTrace();
				}
			}
		}*/
		
		public void shutdown()
		{
			try {
				sChannel.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		

		
		
		
		
		/*
		  private static byte[] data = new byte[255];
  public static void main(String[] args) throws IOException {
    for (int i = 0; i < data.length; i++)
      data[i] = (byte) i;
    ServerSocketChannel server = ServerSocketChannel.open();
    server.configureBlocking(false);
    server.socket().bind(new InetSocketAddress(9000));
    Selector selector = Selector.open();
    server.register(selector, SelectionKey.OP_ACCEPT);
    while (true) {
      selector.select();
      Set readyKeys = selector.selectedKeys();
      Iterator iterator = readyKeys.iterator();
      while (iterator.hasNext()) {
        SelectionKey key = (SelectionKey) iterator.next();
        iterator.remove();
        if (key.isAcceptable()) {
          SocketChannel client = server.accept();
          System.out.println("Accepted connection from " + client);
          client.configureBlocking(false);
          ByteBuffer source = ByteBuffer.wrap(data);
          SelectionKey key2 = client.register(selector, SelectionKey.OP_WRITE);
          key2.attach(source);
        } else if (key.isWritable()) {
          SocketChannel client = (SocketChannel) key.channel();
          ByteBuffer output = (ByteBuffer) key.attachment();
          if (!output.hasRemaining()) {
            output.rewind();
          }
          client.write(output);
        }
        key.channel().close();
      }
    }
  }
}
		 */
		
}
