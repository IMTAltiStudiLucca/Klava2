/*
 * Created on Feb 23, 2006
 */
package klava.gui;

import klava.topology.KlavaNode;

/**
 * @author Lorenzo Bettini
 * @version $Revision: 1.1 $
 */
public class NodeMonitorPanel extends org.mikado.imc.gui.NodeMonitorPanel {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    /**
     * 
     */
    public NodeMonitorPanel(KlavaNode node) {
        super(node);
    }

}
