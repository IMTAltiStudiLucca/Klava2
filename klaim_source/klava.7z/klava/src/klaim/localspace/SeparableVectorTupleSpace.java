/*
 * Created on 30 Oct 2016
 */
package klaim.localspace;

public class SeparableVectorTupleSpace extends SeparableTupleSpace<TupleSpaceVector>
{
    public SeparableVectorTupleSpace()
    {
        super(TupleSpaceVector.class);        
    }
}
