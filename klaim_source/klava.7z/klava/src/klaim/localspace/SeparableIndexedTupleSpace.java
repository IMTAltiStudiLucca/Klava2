/*
 * Created on 30 Oct 2016
 */
package klaim.localspace;

import klava.index_space.IndexedTupleSpace;

public class SeparableIndexedTupleSpace extends SeparableTupleSpace<IndexedTupleSpace>
{
    public SeparableIndexedTupleSpace()
    {
        super(IndexedTupleSpace.class);        
    }
}
