/*
 * Created on 30 Oct 2016
 */
package klaim.localspace;

import klava.index_space.IndexedTupleSpace;

public class SeparableHashtableTupleSpace extends SeparableTupleSpace<TupleSpaceHashtable>
{
    public SeparableHashtableTupleSpace()
    {
        super(TupleSpaceHashtable.class);        
    }
}
