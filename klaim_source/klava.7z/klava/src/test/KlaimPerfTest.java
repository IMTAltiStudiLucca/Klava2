/*
 * Created on 23 Aug 2016
 */
package test;

import org.mikado.imc.common.IMCException;

import com.clarkware.profiler.Profiler;

import klava.KlavaException;
import klava.PhysicalLocality;
import klava.Tuple;
import klava.topology.ClientNode;
import klava.topology.KlavaNode;
import klava.topology.Net;

public class KlaimPerfTest {

    public static void main(String[] args) throws KlavaException, IMCException, InterruptedException {

/*        PhysicalLocality serverLoc = new PhysicalLocality("tcp-127.0.0.1:9997");

        KlavaNode serverNode = new Net(serverLoc);

        KlavaNode c1 = new ClientNode(serverLoc);
        KlavaNode c2 = new ClientNode(serverLoc);*/
        
        PhysicalLocality phLocClient1 = new PhysicalLocality("tcp-127.0.0.1:6001");
        PhysicalLocality phLocClient2 = new PhysicalLocality("tcp-127.0.0.1:6002");
        KlavaNode c1 = new KlavaNode(phLocClient1);
        KlavaNode c2 = new KlavaNode(phLocClient2);

        
        
        Tuple tuple = new Tuple("client2", 100);
   //     c1.out(tuple, c2.getPhysical(KlavaNode.self));
        
        Tuple template = new Tuple("client2", Integer.class);
       /* c1.read(template, c2.getPhysical(KlavaNode.self));
        
        template = new Tuple("client2", Integer.class);
        c1.read(template, c2.getPhysical(KlavaNode.self));
        */

        
        

        for(int i =0; i<20; i++)
        {
            Profiler.begin("OUT");
            c1.out(tuple, c2.getPhysical(KlavaNode.self));
            Profiler.end("OUT");
           
            System.out.println("write to server");
        }
        
        System.out.println("writing finished");
        
  /*      for(int i =0; i<1000; i++)
        {
            template = new Tuple("client2", Integer.class);
            
            Profiler.begin("READ");
            c1.read_nb(template, c2.getPhysical(KlavaNode.self));
            Profiler.end("READ");
            
            System.out.println("reading " + i);
        }
        
        System.out.println("reading finished");
        */
        
        Profiler.print();
        
        Thread.sleep(10000);
    }

}
