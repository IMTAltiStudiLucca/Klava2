/*
 * Created on 27 Oct 2016
 */
package test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

import org.mikado.imc.common.IMCException;

import com.clarkware.profiler.Profiler;
import com.sun.org.apache.xpath.internal.operations.Bool;

import common.TupleLogger;
import klaim.localspace.SeparableHashtableTupleSpace;
import klaim.localspace.SeparableIndexedTupleSpace;
import klaim.localspace.SeparableTupleSpace;
import klaim.localspace.SeparableVectorTupleSpace;
import klaim.localspace.TupleSpaceHashtable;
import klaim.localspace.TupleSpaceVector;
import klava.KlavaException;
import klava.KlavaMalformedPhyLocalityException;
import klava.PhysicalLocality;
import klava.Tuple;
import klava.index_space.IndexedAsyncTupleSpace;
import klava.index_space.IndexedTupleSpace;
import klava.topology.KlavaNode;
import profiler.DProfiler;

public class TestTupleSpace {
    
    public static void main(String[] args) throws KlavaException, IMCException, InterruptedException, FileNotFoundException, IOException {
        
       // writeTest(TupleSpaceVector.class);
        
       // writeTest(IndexedTupleSpace.class);
        
        //writeTest(IndexedAsyncTupleSpace.class);
        
      //  writeAndRead(TupleSpaceVector.class);
        
       // writeAndRead(TupleSpaceHashtable.class);
      //  writeAndRead(IndexedTupleSpace.class);
      //  writeAndRead(IndexedAsyncTupleSpace.class);
        
      writeAndReadDifferentTuple(TupleSpaceVector.class);   // SeparableHashtableTupleSpace
   /*     
        String executionFolder = System.getProperty("user.dir");
        TupleLogger.printStatistics(executionFolder, "a890c10b-0c90-4b75-ba0e-a5a10f6dbdb5",
                new String[] { "write::local", "read::local", "take::local","writing"}); */
    }

    static Random random = new Random();




    
    public static void writeTest(Class tupleSpaceClass) throws KlavaMalformedPhyLocalityException, FileNotFoundException, IOException
    {
        PhysicalLocality phLocClient1 = new PhysicalLocality("tcp-127.0.0.1:6001");
        KlavaNode c1 = new KlavaNode(phLocClient1, tupleSpaceClass);       
        
        Hashtable<String, Boolean[]> settings = new Hashtable<String, Boolean[]>();
        settings.put("type1", new Boolean[]{true, true, false});
       // settings.put("type1", new Boolean[]{true, true, true, true, true, true, false});
    //    settings.put("type1", new Boolean[]{true, true, true, true, true, true, true, true, true, false});
        c1.setSettings(settings);
        
        
        String testKey = UUID.randomUUID().toString();
        
        int tupleNumber = 1000;
        
        TupleLogger.begin("writing");
        for(int i=0; i<tupleNumber; i++)
        {
            Tuple tuple = TupleGenerator("type1", 3, 1);
            TupleLogger.begin("write::local");
            c1.out(tuple);        
            TupleLogger.end("write::local");
            
            if(i % 10000 == 0)
            {
                System.out.println(i);
                System.gc();
            }
        }
        TupleLogger.end("writing");
        
        System.out.println("tuple's work finished");    
        
        DProfiler.writeTestKeyToFile(testKey);

        String executionFolder = System.getProperty("user.dir");
        System.out.println(executionFolder);
        TupleLogger.writeAllToFile(testKey);
        TupleLogger.printStatistics(executionFolder, testKey,
                new String[] { "write::local", "writing"});

        System.out.println("test finished");    
        return;
    }

    public static void writeAndReadDifferentTuple(Class tupleSpaceClass) throws FileNotFoundException, IOException, KlavaException
    {
        PhysicalLocality phLocClient1 = new PhysicalLocality("tcp-127.0.0.1:6001");
        KlavaNode c1 = new KlavaNode(phLocClient1, tupleSpaceClass);       
        
        int tupleNumber = 500000;
        int tupleToRead = 250;
        int fieldNumber = 9;
        int tupleTypeNumber = 10;
        
        Hashtable<String, Boolean[]> settings = new Hashtable<String, Boolean[]>();
        
        if(fieldNumber == 3)
            for(int i =0; i<tupleTypeNumber; i++)
                settings.put("type"+i, new Boolean[]{true, true, false});
        else if(fieldNumber == 6)
            for(int i =0; i<tupleTypeNumber; i++)
                settings.put("type"+i, new Boolean[]{true, true, true, true, true, false});
        else if(fieldNumber == 9)
            for(int i =0; i<tupleTypeNumber; i++)
                settings.put("type"+i, new Boolean[]{true, true, true, true, true, true, true, true, false});
        c1.setSettings(settings);
        
        
        String testKey = UUID.randomUUID().toString();
        

        
        ArrayList<Integer> readTupleIDs = new ArrayList<Integer>();
        ArrayList<Tuple> readTuples = new ArrayList<Tuple>();
        for(int i =0; i<tupleToRead; i++)
            readTupleIDs.add(getRandomInteger(tupleNumber));
        
        
        TupleLogger.begin("writing");
        for(int i=0; i<tupleNumber; i++)
        {           
            Tuple tuple = TupleGenerator("type", fieldNumber, tupleTypeNumber);
            
            if(readTupleIDs.contains(i))
                readTuples.add((Tuple)tuple.clone());
                
            TupleLogger.begin("write::local");
            c1.out(tuple);        
            TupleLogger.end("write::local");
            
            if(i % 50000 == 0)
            {
                System.out.println(i);
                System.gc();
            }
        }
        TupleLogger.end("writing");
        System.out.println("writing finished");    
        
        
        for(int i=0; i<readTuples.size(); i++)
        {
            Tuple template = readTuples.get(i);
            template = transformToTemplate((Tuple)template.clone());
            
            TupleLogger.begin("read::local");
            c1.read(template);
            TupleLogger.end("read::local");
        }      
        System.out.println("reading finished");    
        
        for(int i=0; i<readTuples.size(); i++)
        {
            Tuple template = readTuples.get(i);
            template = transformToTemplate((Tuple)template.clone());
            
            TupleLogger.begin("take::local");
            c1.in(template);
            TupleLogger.end("take::local");
        }
        System.out.println("taking finished");    
        
        System.out.println("tuple's work finished");    
        
        DProfiler.writeTestKeyToFile(testKey);

        String executionFolder = System.getProperty("user.dir");
        System.out.println(executionFolder);
        TupleLogger.writeAllToFile(testKey);
        TupleLogger.printStatistics(executionFolder, testKey,
                new String[] { "write::local", "read::local", "take::local","writing"});

        System.out.println("test finished");    
    
    }


    
    public static void writeAndRead(Class tupleSpaceClass) throws FileNotFoundException, IOException, KlavaException
    {
        PhysicalLocality phLocClient1 = new PhysicalLocality("tcp-127.0.0.1:6001");
        KlavaNode c1 = new KlavaNode(phLocClient1, tupleSpaceClass);       
        
        int tupleNumber = 500000;
        int tupleToRead = 250;
        int fieldNumber = 9;
        int tupleTypeNumber = 1;
        
        Hashtable<String, Boolean[]> settings = new Hashtable<String, Boolean[]>();
        
        if(fieldNumber == 3)
            settings.put("type1", new Boolean[]{true, true, false});
        else if(fieldNumber == 6)
            settings.put("type1", new Boolean[]{true, true, true, true, true, false});
        else if(fieldNumber == 9)
            settings.put("type1", new Boolean[]{true, true, true, true, true, true, true, true, false});
        c1.setSettings(settings);
        
        
        String testKey = UUID.randomUUID().toString();
        

        
        ArrayList<Integer> readTupleIDs = new ArrayList<Integer>();
        ArrayList<Tuple> readTuples = new ArrayList<Tuple>();
        for(int i =0; i<tupleToRead; i++)
            readTupleIDs.add(getRandomInteger(tupleNumber));
        
        
        TupleLogger.begin("writing");
        for(int i=0; i<tupleNumber; i++)
        {           
            Tuple tuple = TupleGenerator("type", fieldNumber, tupleTypeNumber);
            
            if(readTupleIDs.contains(i))
                readTuples.add((Tuple)tuple.clone());
                
            TupleLogger.begin("write::local");
            c1.out(tuple);        
            TupleLogger.end("write::local");
            
            if(i % 10000 == 0)
            {
                System.out.println(i);
                System.gc();
            }
        }
        TupleLogger.end("writing");
        System.out.println("writing finished");    
        
        
        for(int i=0; i<readTuples.size(); i++)
        {
            Tuple template = readTuples.get(i);
            template = transformToTemplate((Tuple)template.clone());
            
            TupleLogger.begin("read::local");
            c1.read(template);
            TupleLogger.end("read::local");
        }      
        System.out.println("reading finished");    
        
        for(int i=0; i<readTuples.size(); i++)
        {
            Tuple template = readTuples.get(i);
            template = transformToTemplate((Tuple)template.clone());
            
            TupleLogger.begin("take::local");
            c1.in(template);
            TupleLogger.end("take::local");
        }
        System.out.println("taking finished");    
        
        System.out.println("tuple's work finished");    
        
        DProfiler.writeTestKeyToFile(testKey);

        String executionFolder = System.getProperty("user.dir");
        System.out.println(executionFolder);
        TupleLogger.writeAllToFile(testKey);
        TupleLogger.printStatistics(executionFolder, testKey,
                new String[] { "write::local", "read::local", "take::local","writing"});

        System.out.println("test finished");    
    
    }



    private static void someMethod() throws KlavaMalformedPhyLocalityException,
            KlavaException, InterruptedException {
        PhysicalLocality phLocClient1 = new PhysicalLocality("tcp-127.0.0.1:6001");
        PhysicalLocality phLocClient2 = new PhysicalLocality("tcp-127.0.0.1:6002");
        
        // IndexedTupleSpace  IndexedAsyncTupleSpace TupleSpaceHashtable TupleSpaceVector SeparableVectorTupleSpace
        KlavaNode c1 = new KlavaNode(phLocClient1, SeparableVectorTupleSpace.class);       
        //KlavaNode c2 = new KlavaNode(phLocClient2);

        
        // load settings
        // for each template
        // (Integer.class, String.class)
        Hashtable<String, Boolean[]> settings = new Hashtable<String, Boolean[]>();
        settings.put("ex_tuple", new Boolean[]{true, false});
        c1.setSettings(settings);
        
        Tuple tuple = new Tuple("ex_tuple", new Object[]{"client2", 100});
        c1.out(tuple);
        
        
        Tuple template = new Tuple("ex_tuple", new Object[]{"client2", Integer.class});
        c1.read(template);
        
        template = new Tuple("ex_tuple", new Object[]{"client2", Integer.class});
        c1.in(template);
        
        System.out.println(template);
        
        
        
        System.out.println("writing finished");
        
        Profiler.print();
        
        Thread.sleep(1000);
    }
    
    
    
    
    
    
    public static Tuple transformToTemplate(Tuple tuple)
    {
        int lastFieldIndex = tuple.length() - 1;
        if(lastFieldIndex % 2 == 0)
            tuple.setItem(tuple.length() - 1, String.class);
        else
            tuple.setItem(tuple.length() - 1, Integer.class);
        
        return tuple;
    }
    
    
    public static Tuple TupleGenerator(String name, int length, int tupleTypeNumber)
    {
        int tupleTypeID = getRandomInteger(tupleTypeNumber);
        Object[] dataArray = new Object[length];  
        for(int i =0; i <dataArray.length; i++)
        {
            if(i%2 == 0)
            {
                dataArray[i] = getRandomString(20);
            } else
            {
                dataArray[i] = getRandomInteger(10000);
            }
        }
        
        Tuple tuple = new Tuple(name + tupleTypeID, dataArray);
        return tuple;
    }
    
    
    
    public static String getRandomString(int length)
    {
        char[] chars = "abcdefghijklmnopqrstuvwxyz".toCharArray();
        StringBuilder sb = new StringBuilder();
        //Random random = new Random();
        for (int i = 0; i < length; i++) {
            char c = chars[random.nextInt(chars.length)];
            sb.append(c);
        }
        String output = sb.toString();
        return output;
    }
    
    public static Integer getRandomInteger(int range)
    {
        //Random random = new Random();
        Integer number = random.nextInt(range);
        return number;
    }

}
